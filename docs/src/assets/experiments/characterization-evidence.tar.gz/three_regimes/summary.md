# Three Regimes — same spikes, three notions of focus

**Slug:** `three_regimes` · **Run:** `julia --project=experiments experiments/three_regimes.jl`

## Research question

Given exactly the same synthetic spike scene, how do `spike_attention_discrete`,
`spike_attention_temporal`, and `spike_attention_continuous` differ in what they
preserve, decay, and reject?

## Hypothesis

1. **Discrete** ignores timing and accumulates every matching-neuron interaction regardless of age.
2. **Temporal** keeps every matching-neuron interaction but exponentially downweights stale ones.
3. **Continuous** applies the same decay *and* an explicit temporal window, rejecting pairs outside it.

## Setup

- One deterministic scene of 5 source and 5 context spikes across 5 neurons; no randomness, no seed needed.
- Identity readout (5×5), so the kernel output *is* the per-neuron attention vector.
- `τ = 0.2` for both temporal and continuous.
- `TemporalBuffer` window `= 0.25` on both buffers (the kernel uses `min(source, context)`).
- `prune!` is deliberately **not** applied, so temporal and continuous differ by exactly one thing: the kernel's `|Δt| <= window` test.

## Which events contributed, per regime

| pair | neuron | Δt | discrete | temporal | continuous |
| --- | --- | --- | --- | --- | --- |
| `aligned_recent` | n1 · aligned-recent | 0.010 | 1.000 | 0.951 | 0.951 |
| `moderate_lag` | n2 · moderate-lag | 0.180 | 1.000 | 0.407 | 0.407 |
| `stale_distractor` | n3 · stale-distractor | 0.880 | 1.000 | 0.012 | — *(window)* |
| `unrelated_neuron` | n4 · unrelated | — | — *(no match)* | — *(no match)* | — *(no match)* |
| `boundary_inside` | n5 · window-boundary | 0.240 | 1.000 | 0.301 | 0.301 |
| `boundary_outside` | n5 · window-boundary | 0.260 | 1.000 | 0.273 | — *(window)* |

## Per-neuron attention mass (share of total)

| neuron | role | discrete | temporal | continuous |
| --- | --- | --- | --- | --- |
| n1 | aligned-recent | 1.0000 (20.0%) | 0.9512 (48.9%) | 0.9512 (57.3%) |
| n2 | moderate-lag | 1.0000 (20.0%) | 0.4066 (20.9%) | 0.4066 (24.5%) |
| n3 | stale-distractor | 1.0000 (20.0%) | 0.0123 (0.6%) | 0.0000 (0.0%) |
| n4 | unrelated | 0.0000 (0.0%) | 0.0000 (0.0%) | 0.0000 (0.0%) |
| n5 | window-boundary | 2.0000 (40.0%) | 0.5737 (29.5%) | 0.3012 (18.2%) |

| | discrete | temporal | continuous |
| --- | --- | --- | --- |
| **winner neuron** | n5 | n1 | n1 |
| **total mass** | 5.0000 | 1.9438 | 1.6590 |

## Observation

- **Discrete is timing-blind.** The stale pair (n3, Δt = 0.88) contributes 1.000 — exactly as much as the freshly aligned pair on n1. It cannot tell a 0.88-old coincidence from a 0.01-old one.
- **Temporal decays but has no cutoff.** n3 drops to 0.0123 (0.6% of total mass) and is still counted: `spike_attention_temporal` applies no window, so no pair is excluded *by rule*. Note this is not a guarantee of a strictly positive weight — `temporal_weight` is `exp(-|Δt|/τ)` in `Float32`, which underflows to exactly `0.0` once `|Δt|/τ` reaches 104 (measured on this machine). That is a numeric floor, not a semantic cutoff.
- **Continuous rejects.** n3 falls to exactly 0.0000 because |Δt| = 0.88 exceeds the window of 0.25.
- **The boundary is sharp.** n5 carries two context spikes at Δt = 0.24 and Δt = 0.26. Discrete counts both (mass 2.000), temporal counts both with decay (0.5737), continuous keeps only the inner one (0.3012).
- **Focus itself moves.** The winner is n5 under discrete (pair *count* wins), but n1 under temporal and continuous (*recency* wins).
- **Unrelated stays silent.** n4 spikes but has no context partner, so it holds 0.0000 mass in every regime.

## Verdict

**Supported.** All three predicted behaviors are reproduced on identical input.
The regimes form a strict refinement chain on this scene: discrete ⊇ temporal (same
support, reweighted) ⊇ continuous (support truncated at ±0.25).
Choose *discrete* when only coincidence identity matters, *temporal* when old
evidence should fade continuously with no explicit cutoff, and *continuous* when
old evidence must be provably excluded.

## Artifacts

- `config.toml` — every τ / window / timing value used by this run
- `metrics.csv` — one row per (regime, labeled pair) with pair weight, status, neuron mass, share, winner
- `figure.png` — the scene plus all three regime outputs
