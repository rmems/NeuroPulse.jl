# Harness smoke — τ sweep from coincidence to timing-insensitive attention

## Question

What happens to `spike_attention_temporal` on a fixed spike scene as the
time constant τ is swept over four orders of magnitude?

## Hypothesis

Larger τ flattens the exponential recency weight `exp(-|Δt| / τ)` toward
1, so every component of the temporal readout should grow with τ, stay
at or below the timing-agnostic `spike_attention_discrete` readout, and
converge to it elementwise at the largest τ — within 0.01 of the
largest discrete readout component.

## Setup

Seed 42 (`MersenneTwister`), 48 source and 48
context events over 16 neurons, spike times uniform on
`[0, 1)`, non-negative 16×4 readout, τ from
0.01 to 200. Full configuration in `config.toml`.

## Result

| τ | ‖temporal readout‖ | ratio to discrete | max elementwise deviation |
|---:|---:|---:|---:|
| 0.01 | 4.8203 | 0.0321 | 0.9648 |
| 0.02 | 9.5498 | 0.0635 | 0.9305 |
| 0.05 | 19.1210 | 0.1272 | 0.8594 |
| 0.1 | 31.0473 | 0.2066 | 0.7712 |
| 0.2 | 50.1470 | 0.3336 | 0.6370 |
| 0.5 | 85.0612 | 0.5659 | 0.4079 |
| 1 | 109.8806 | 0.7311 | 0.2510 |
| 2 | 127.5079 | 0.8484 | 0.1410 |
| 5 | 140.4549 | 0.9345 | 0.0608 |
| 10 | 145.2454 | 0.9664 | 0.0312 |
| 50 | 149.2668 | 0.9931 | 0.0064 |
| 200 | 150.0403 | 0.9983 | 0.0016 |

Deviations are `max|temporal - discrete|` divided by the largest
discrete readout component.

- every component non-decreasing in τ: **true**
- no component exceeds the discrete baseline: **true**
- at τ = 200: norm ratio **0.9983**, max elementwise
  deviation **0.0016** (converged: **true**)

At the shortest τ the readout keeps only near-coincident pairs
(3.2% of the discrete magnitude); by τ = 200 the
kernel is effectively timing-insensitive and reproduces coincidence
attention.

## Verdict

The observation **supports** the hypothesis.

## Artifacts

`config.toml`, `metrics.csv`, `figure.png`, `summary.md` in this directory.

## Reproduce

```bash
julia --project=experiments experiments/harness_smoke.jl
```
