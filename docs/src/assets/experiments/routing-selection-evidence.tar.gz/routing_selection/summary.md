# Controlled routing selection

**Primary verdict: unsupported.** Full temporal routing versus the fixed temporal-attention baseline across 243 paired scenes.

The declared descriptive rule requires mean target-share gain ≥ 0.01, strict-top1 gain ≥ 0.02, and no increase in missed handoffs or phase-capped delay. Nonpositive share/accuracy gain or an increase in misses/delay is unsupported; remaining positive gains are inconclusive. These are finite-grid comparisons, not population-level significance tests. The parameters and grid are declared in the input TOML before evaluation.

| Method | Target share | Strict top1 | Missed / handoffs | Capped delay (s) | Mean weight turnover | No-evidence coverage | Verdict vs temporal |
|---|---:|---:|---:|---:|---:|---:|---|
| uniform | 0.16667 | 0.0 | 729 / 729 | 1.2 | 0.0 | 0.81114 | unsupported |
| firing_rate | 0.40723 | 0.47429 | 201 / 729 | 0.7758 | 0.06872 | 0.01979 | unsupported |
| discrete_attention | 0.50031 | 0.49583 | 212 / 729 | 0.73967 | 0.07861 | 0.04387 | unsupported |
| temporal_attention | 0.48883 | 0.51644 | 207 / 729 | 0.71523 | 0.07202 | 0.04387 | baseline |
| temporal_router | 0.18383 | 0.24751 | 359 / 729 | 0.77473 | 0.08231 | 0.01979 | unsupported |
| no_surprise | 0.17164 | 0.60652 | 159 / 729 | 0.70946 | 0.00173 | 0.01979 | unsupported |
| no_momentum | 0.18358 | 0.24669 | 358 / 729 | 0.77374 | 0.08248 | 0.01979 | unsupported |
| no_inhibition | 0.18397 | 0.24742 | 359 / 729 | 0.77473 | 0.08164 | 0.01979 | unsupported |

Primary paired target-share gain: -0.30499658; strict-top1 gain: -0.26893514267251645.

Every sample contributes to share and accuracy, including held allocations on missing intervals. A unique exact maximum is required; ties are incorrect. Handoffs require five consecutive observed correct samples, report confirmation delay, and record misses explicitly. The phase-length cap penalizes every miss instead of dropping it from the average. Weight turnover is mean total-variation distance between consecutive allocations. Initial acquisition is excluded from the three switch handoffs.

Mean observation coverage: 0.8111417202326296. Full router observed no-input-evidence coverage over all scheduled samples: 0.019793898581777367. Missing intervals have unknown evidence (blank CSV cell), discard their arrivals, and hold method weights/router state. Observed silence still advances the router. Density counts occupied source bins divided by observed recent bins; No-evidence is computed separately for each method from the inputs it consumes: source density for rate, raw attention for attention methods, and either density or temporal attention for routers; the uniform comparator consumes no data and always has no data evidence. One neuron maps to one region, and the one-element router readout is the normalized temporal attention score, or zero when no evidence exists.

This controlled spike study does not establish deployed Spikenaut performance, training benefit, or hardware efficiency. The router uses density, *relative readout surprise*, and momentum; it does not pass the attention share straight through. Consequently, a strongly changing distractor can receive high router weight. Router ablations zero one coefficient or the equal off-diagonal inhibition matrix without renormalizing other coefficients. No hyperparameters were fitted to these results.

Artifacts: metrics.csv (scene × method), paired.csv (paired differences), handoffs.csv (every switch including failures), traces.csv (per-tick weights and evidence), events.csv (generated input plus provenance roles), masks.csv (availability and evaluation targets), aggregate.csv, config.toml (full effective configuration), figure.png, provenance.toml and resolved Project/Manifest snapshots. Runtime observations strip roles and targets; labels are used only in generation and evaluation. Hashes in provenance cover all auxiliary CSV files and the input configuration as well as source and environment files.
