# Offline Spikenaut replay: descriptive allocation report

**Data kind: synthetic.** 10 original ticks, 2 sessions, 32 upstream spikes. The default committed fixture is synthetic method data, not measured hardware or a holdout. Explicit external inputs default to `unverified/unspecified`; a measured label is only a caller declaration.

Question: how do allocation concentration, entropy and turnover change over the declared window grid when the same current spikes query strictly earlier context? There are no target labels, accuracy tests, forecasts, or supervisor conclusions in this study. A concentrated allocation does not establish a correct or useful allocation. No parameters are fitted to these results.

| Window (ticks) | Method | Eligible / all | No evidence / eligible | HHI concentration | Entropy (bits) | Turnover | Consecutive pairs |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | uniform | 8 / 10 | 8 / 8 | 0.0625 | 4.0 | 0.0 | 6 |
| 1 | firing_rate | 8 / 10 | 2 / 8 | 0.14062 | 3.0 | 0.5 | 6 |
| 1 | discrete_attention | 8 / 10 | 8 / 8 | 0.0625 | 4.0 | 0.0 | 6 |
| 1 | temporal_attention | 8 / 10 | 8 / 8 | 0.0625 | 4.0 | 0.0 | 6 |
| 1 | temporal_router | 8 / 10 | 2 / 8 | 0.06299 | 3.99437 | 0.0369 | 6 |
| 2 | uniform | 8 / 10 | 8 / 8 | 0.0625 | 4.0 | 0.0 | 6 |
| 2 | firing_rate | 8 / 10 | 2 / 8 | 0.13715 | 3.06291 | 0.51389 | 6 |
| 2 | discrete_attention | 8 / 10 | 6 / 8 | 0.17188 | 3.25 | 0.3125 | 6 |
| 2 | temporal_attention | 8 / 10 | 6 / 8 | 0.17188 | 3.25 | 0.3125 | 6 |
| 2 | temporal_router | 8 / 10 | 2 / 8 | 0.13991 | 3.49167 | 0.2864 | 6 |
| 4 | uniform | 8 / 10 | 8 / 8 | 0.0625 | 4.0 | 0.0 | 6 |
| 4 | firing_rate | 8 / 10 | 2 / 8 | 0.13498 | 3.09395 | 0.49306 | 6 |
| 4 | discrete_attention | 8 / 10 | 6 / 8 | 0.17188 | 3.25 | 0.3125 | 6 |
| 4 | temporal_attention | 8 / 10 | 6 / 8 | 0.17188 | 3.25 | 0.3125 | 6 |
| 4 | temporal_router | 8 / 10 | 2 / 8 | 0.13991 | 3.49167 | 0.2864 | 6 |
| 8 | uniform | 8 / 10 | 8 / 8 | 0.0625 | 4.0 | 0.0 | 6 |
| 8 | firing_rate | 8 / 10 | 2 / 8 | 0.13498 | 3.09395 | 0.49306 | 6 |
| 8 | discrete_attention | 8 / 10 | 6 / 8 | 0.17188 | 3.25 | 0.3125 | 6 |
| 8 | temporal_attention | 8 / 10 | 6 / 8 | 0.17188 | 3.25 | 0.3125 | 6 |
| 8 | temporal_router | 8 / 10 | 2 / 8 | 0.13991 | 3.49167 | 0.2864 | 6 |

One neuron is one analysis region; producer IDs 0:15 map explicitly to Julia IDs 1:16. This is an analysis choice, not a claimed anatomical or functional grouping. Source is the current tick only, and context is previous ticks from the same session with lag in 1:window. Events are compared by matching neuron ID, so a first tick has no past-context attention evidence. Discrete attention ignores lag within this same pruned context; temporal attention applies exp(-lag/tau). Tick spacing is not known elapsed time: these inputs have no usable timestamps and staleness is undetectable.

Firing-rate density counts occupied bins in [t-window,t], including current tick, divided by the available bins in that window (shortened at session start). Each router region receives that density and one temporal L1 attention share; absent attention gives zero readout. All positive raw comparator scores are L1-normalized. With zero scores, allocation is uniform and evidence=false. Observed silence still advances an eligible router, whose history can affect its weights. Uniform is data-independent and always has evidence=false. Exact ties have no unique winner.

Any missing sensor marks its entire row unobserved and excludes every comparison whose closed [t-window,t] includes it. Missing arrivals are discarded, local event history and router state are reset, and observed subsequent ticks accumulate context while routing stays reset until the local window is clear. Original global steps are retained; windows are never shortened by compressing time. Every session independently resets history, router and turnover. **This excludes local contamination; it does not undo upstream LIF state that already evolved through encode-zero sensor dropout and does not prove upstream recovery.**

Coverage retains observed silence separately from missing/unobserved rows. In traces.csv and coverage.csv, unknown silence/evidence and excluded statistics are blank, not zero. Metrics average only eligible ticks, including observed zero-evidence uniform fallbacks; different windows may have different eligible sets. Turnover is total variation between consecutive eligible same-session allocations, never across an excluded interval or boundary. HHI is sum(p²), entropy is -sum(p log2 p). No significance or performance-benefit claim follows from these pooled descriptive means.

The producer manifest is preserved verbatim in input-manifest.json, including source commit/dirty fields, checkpoint and input lineage. Trace SHA-256 and schema declarations are verified along with neuron IDs, vector shapes, finite inputs, ordered sessions and aggregate counts. A digest checks consistency, not authenticity; producer checkpoint and original external telemetry are not independently re-attested here. The committed telemetry fixture is included and its declared input digest is checked. Upstream scores and decision diagnostics are not used to select routing weights or interpreted as a validated action policy.

Artifacts: config.toml records effective configuration and analysis policies; metrics.csv is window × method; traces.csv records all method/tick allocations; coverage.csv records each window/tick's masks, observation state and eligibility; input-trace.jsonl and input-manifest.json preserve exact supplied bytes. Provenance covers both inputs, configuration, auxiliary tables, source files and resolved Project/Manifest snapshots. The plot is descriptive and the supplied data kind is shown in its title.
